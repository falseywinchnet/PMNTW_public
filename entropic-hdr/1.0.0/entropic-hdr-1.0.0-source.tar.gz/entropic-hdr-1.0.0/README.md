# Entropic HDR 1.0.0 — 16 October 2026 release

Entropic HDR is a single-filter OBS Studio module. It measures local color
entropy on a sparse lattice of the live picture and uses it to decide where to
stretch brightness and color contrast: a regularized decorrelation stretch,
with tonal range allocated to the colors that carry the most local detail.
The profile adapts continuously to each scene and is applied on the GPU as a
33³ color table.

In OBS's Filters list it appears as **Entropic HDR**. Defaults are
decorrelation 0.09 and allocation 0.11, with Chains off.

## Origin and compatibility

The filter first shipped as Entropy-Guided Decorrelation Stretch inside
Realtime Vector FX 0.4.0 (release 2026.09.10). This module contains only that
filter and the entropy core it uses; Posterizer Mark IV, the Realtime Vector FX
effects and their shared GPU filter code are not included.

- The internal source id stays `entropy_decorrelation_stretch`, so scenes saved
  with Realtime Vector FX 0.4.0 load with Entropic HDR. Explicitly saved values
  are kept; values left at the old defaults (0.65/0.80) take the new defaults.
- The entropy core (`src/entropy_stretch.cpp`, `include/rvfx/entropy_stretch.hpp`),
  tests, frozen references and the GPU shader are byte-identical to 2026.09.10.
  `rvfx::entropy::Config` keeps its historical 0.65/0.80 member defaults, which
  the frozen-reference tests exercise; the shipped look is set in
  `include/entropic_hdr/defaults.hpp` and used by the OBS defaults and the CPU
  reference renderer.
- Loading Realtime Vector FX 0.4.0 and Entropic HDR together registers the id
  once. OBS 32.2.1 refuses a second registration of an existing id
  (`obs_register_source_s`, "Duplicate library?"), so if Entropic HDR loads
  first, Realtime Vector FX's copy is declined by libobs and its other filters
  still register. If Realtime Vector FX loads first, Entropic HDR checks
  `obs_source_get_display_name` before registering, logs that the id is already
  provided and loads without registering. It still reports a successful load, so
  OBS shows no plugin-failure dialog. OBS loads the modules in each plugin folder
  in sorted `glob` order, so a shared plugin folder puts `entropic-hdr` first.

The design notes in `docs/` were written while the filter was part of
Realtime Vector FX; their build paths refer to that tree.

## Layout

| Path | Contents |
| --- | --- |
| `src/`, `include/rvfx/` | entropy core: lattice analysis, whitening, entropy CDFs, Chains, temporal LUT |
| `include/entropic_hdr/defaults.hpp` | source id, display name and shipped defaults |
| `obs/` | OBS filter (shader, capture, readback, properties) and module entry |
| `tests/` | core invariants, Chains composition, frozen v1 references |
| `tools/entropy_demo.cpp` | CPU reference renderer for P6 PPM images |
| `tools/entropy_benchmark.cpp` | bit-exact frozen-reference equivalence (`--verify-only`) |
| `tools/entropy_obs_smoke.mm`, `tools/dual_module_smoke.mm`, `tools/inspect-module.cpp` | libobs/Metal runtime checks |
| `tools/build-release.sh`, `tools/run-macos-checks.sh`, `tools/package-release.py` | release build, runtime checks, packaging |
| `toolchains/` | Windows (MinGW-w64) and Linux (Zig) cross toolchains |
| `evidence/` | dependency digests, build logs, ABI audit and runtime logs for this release |

## Targets and verification

- Windows x64: MinGW-w64 14.0.0 / GCC 16.1.0 cross-build, portable x86-64 CPU
  baseline, static GCC/C++/thread runtime, dynamic OBS and Windows system APIs.
- macOS universal: separate arm64 and x86_64 builds with Apple Clang
  21.0.0.21000101 (SDK 26.5), combined using lipo; deployment target macOS 13.0.
  Ad hoc signed, not Developer ID signed or Apple notarized.
- Linux x64: Zig 0.14.1 / Clang 19.1.7 cross-build targeting glibc 2.35, with
  static libc++/libc++abi. Requires the standard native OBS `libobs.so.30` ABI.
  Not a Flatpak package.

All builds use OBS 32.2.1 public headers and SIMDe 0.8.2; only the
`obs_module_*` entry points are exported. Native checks run on an Apple M4 with
isolated official OBS 32.2.1 runtimes and Metal, leaving any installed OBS
untouched: the shipped and 0.4.0 looks, Chains in all six orders, CPU/GPU
agreement, alpha, freeze, zero-strength exact bypass, HDR passthrough, and
single registration with Realtime Vector FX 0.4.0 loaded in either order.
Intel loading, registration, defaults and properties are checked under Rosetta,
which is not native Intel hardware testing. Windows and Linux are cross-built
and binary/ABI inspected, not native runtime tested. These finite fixtures are
not a guarantee for every input, GPU driver or scene configuration.

## Build

CPU tests and the reference renderer need only CMake and a C++17 compiler:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DENTROPIC_HDR_BUILD_OBS=OFF
cmake --build build -j8
ctest --test-dir build --output-on-failure
build/entropy_demo input.ppm output.ppm            # shipped 0.09/0.11 look
build/entropy_demo input.ppm output.ppm 0.65 0.8   # Realtime Vector FX 0.4.0 look
```

The release build runs on an Apple Silicon Mac with Xcode command-line tools,
Homebrew `cmake` and `mingw-w64`. Place the pinned downloads listed in
`tools/build-release.sh` in one folder; they are checked against
`evidence/dependency-digests.json`. Then:

```sh
tools/build-release.sh DEPS_DIR BUILD_ROOT
tools/package-release.py --build-root BUILD_ROOT --staging STAGING --output dist/1.0.0 \
  --baseline-source obs-plugins-2026.09.10-source.tar.gz
tools/run-macos-checks.sh DEPS_DIR STAGING/entropic-hdr.plugin/Contents/MacOS/entropic-hdr \
  realtime-vector-fx.plugin/Contents/MacOS/realtime-vector-fx CHECKS_DIR
```

Pinned inputs:

- OBS source: https://github.com/obsproject/obs-studio/tree/32.2.1
- OBS release libraries: https://github.com/obsproject/obs-studio/releases/tag/32.2.1
- SIMDe: https://github.com/simd-everywhere/simde/tree/v0.8.2
- Zig cross-toolchain: https://ziglang.org/download/0.14.1/
- MinGW-w64: https://github.com/mingw-w64/mingw-w64/tree/v14.0.0

Do not ship the build-local OBS runtime libraries in plugin archives; the host
OBS provides them.

## Licenses

The project source retains its MIT license (`licenses/BFFT-MIT.txt`). The linked
OBS plugin binaries are distributed under GNU GPL version 2 or later, with the
MIT notice retained. OBS headers carry their own GPL/ISC notices. SIMDe is MIT.
Windows static-runtime notices include MinGW, winpthreads, GCC GPLv3 and the GCC
Runtime Library Exception. Linux static-runtime notices include LLVM libc++ and
libc++abi under Apache 2.0 with LLVM exceptions. OBS Studio is not bundled.
