#pragma once
#include "rvfx/entropy_stretch.hpp"

namespace entropic_hdr {
// Kept from Realtime Vector FX so existing scenes still find the filter.
constexpr const char* source_id = "entropy_decorrelation_stretch";
constexpr const char* display_name = "Entropic HDR";
// Shipped look. rvfx::entropy::Config keeps its historical .65/.80 defaults,
// which the frozen-reference equivalence tests exercise.
constexpr double default_decorrelation = .09;
constexpr double default_allocation = .11;
inline rvfx::entropy::Config default_config() {
    rvfx::entropy::Config config;
    config.decorrelation = float(default_decorrelation);
    config.allocation = float(default_allocation);
    return config;
}
} // namespace entropic_hdr
