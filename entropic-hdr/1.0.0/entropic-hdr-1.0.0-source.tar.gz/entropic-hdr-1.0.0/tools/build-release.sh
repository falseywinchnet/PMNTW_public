#!/bin/zsh
# Build Entropic HDR for macOS arm64/x86_64, Windows x64 and Linux x64 on an
# Apple Silicon Mac. Dependencies are build-local; nothing is installed.
#
# usage: tools/build-release.sh DEPS_DIR BUILD_ROOT
#
# DEPS_DIR holds the pinned downloads (verified against evidence/dependency-digests.json):
#   OBS-Studio-32.2.1-macOS-Apple.dmg  OBS-Studio-32.2.1-macOS-Intel.dmg
#   OBS-Studio-32.2.1-Windows-x64.zip  OBS-Studio-32.2.1-Ubuntu-24.04-x86_64.deb
#   obs-studio-32.2.1-src.tar.gz       (github.com/obsproject/obs-studio/archive/refs/tags/32.2.1.tar.gz)
#   simde-0.8.2.tar.gz                 (github.com/simd-everywhere/simde/archive/refs/tags/v0.8.2.tar.gz)
#   zig-aarch64-macos-0.14.1.tar.xz    (ziglang.org/download/0.14.1/)
# Requires Xcode command-line tools, Homebrew cmake, and mingw-w64 (GCC 16.1.0).
set -euo pipefail
ROOT=${0:A:h:h}
DEPS=${1:?DEPS_DIR}; BUILD=${2:?BUILD_ROOT}
DEPS=${DEPS:A}; mkdir -p $BUILD; BUILD=${BUILD:A}
PATH=/opt/homebrew/bin:$PATH
cd $DEPS
python3 -I $ROOT/tools/verify-digests.py $ROOT/evidence/dependency-digests.json $DEPS

[[ -f obs-studio-32.2.1/libobs/obs-module.h ]] || tar -xzf obs-studio-32.2.1-src.tar.gz
[[ -f simde-0.8.2/simde/x86/sse2.h ]] || tar -xzf simde-0.8.2.tar.gz
[[ -x zig-aarch64-macos-0.14.1/zig ]] || tar -xJf zig-aarch64-macos-0.14.1.tar.xz
python3 -I $ROOT/tools/prepare-zig-wrappers.py $DEPS
for arch in arm64 x64; do
  app=$DEPS/OBS-$arch.app; dmg=OBS-Studio-32.2.1-macOS-$([[ $arch == arm64 ]] && echo Apple || echo Intel).dmg
  if [[ ! -d $app ]]; then
    mnt=$(mktemp -d); hdiutil attach -quiet -nobrowse -readonly -mountpoint $mnt $dmg
    ditto $mnt/OBS.app $app; hdiutil detach -quiet $mnt; rmdir $mnt
  fi
done
mkdir -p windows linux
if [[ ! -f windows/libobs.dll.a ]]; then
  unzip -o -q -j OBS-Studio-32.2.1-Windows-x64.zip bin/64bit/obs.dll -d windows
  python3 -I $ROOT/tools/pe_info.py def windows/obs.dll > windows/obs.def
  x86_64-w64-mingw32-dlltool -d windows/obs.def -D obs.dll -l windows/libobs.dll.a
fi
if [[ ! -f linux/libobs.so.30 ]]; then
  tmp=$(mktemp -d); (cd $tmp && ar x $DEPS/OBS-Studio-32.2.1-Ubuntu-24.04-x86_64.deb && tar -xf data.tar.*)
  cp -L $(find $tmp -name libobs.so.30 -print -quit) linux/libobs.so.30; rm -rf $tmp
fi

common=(-DCMAKE_BUILD_TYPE=Release -DOBS_SOURCE_DIR=$DEPS/obs-studio-32.2.1 -DSIMDE_SOURCE_DIR=$DEPS/simde-0.8.2)
for arch in arm64 x64; do
  cmake -S $ROOT -B $BUILD/entropic-hdr-macos-$arch $common -DENTROPIC_HDR_BUILD_TESTS=OFF \
    -DCMAKE_OSX_ARCHITECTURES=$([[ $arch == arm64 ]] && echo arm64 || echo x86_64) -DCMAKE_OSX_DEPLOYMENT_TARGET=13.0 \
    -DOBS_LINK_LIBRARY=$DEPS/OBS-$arch.app/Contents/Frameworks/libobs.framework/libobs
done
cmake -S $ROOT -B $BUILD/entropic-hdr-windows-x64 $common -DCMAKE_TOOLCHAIN_FILE=$ROOT/toolchains/windows-x64.cmake \
  -DOBS_LINK_LIBRARY=$DEPS/windows/libobs.dll.a
OBS_RELEASE_DEPS=$DEPS cmake -S $ROOT -B $BUILD/entropic-hdr-linux-x64 $common -DCMAKE_TOOLCHAIN_FILE=$ROOT/toolchains/linux-x64.cmake \
  -DOBS_LINK_LIBRARY=$DEPS/linux/libobs.so.30
for target in macos-arm64 macos-x64 windows-x64 linux-x64; do
  OBS_RELEASE_DEPS=$DEPS cmake --build $BUILD/entropic-hdr-$target -j8 --target entropic-hdr 2>&1 | tee $BUILD/build-$target.log
done
python3 -I $ROOT/tools/audit-binaries.py $BUILD $DEPS | tee $BUILD/abi-audit.json
