#!/usr/bin/env python3
"""Inspect built Entropic HDR binaries: architectures, exports, imports, unresolved symbols."""
import json, pathlib, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pe_info

build, deps = map(pathlib.Path, sys.argv[1:3])
run = lambda *a: subprocess.run(a, check=True, capture_output=True, text=True).stdout
report = {}
for arch in ('arm64', 'x64'):
    b = build / f'entropic-hdr-macos-{arch}' / 'entropic-hdr'
    exported = sorted(l.split()[-1] for l in run('nm', '-gU', str(b)).splitlines())
    libs = [l.split()[0] for l in run('otool', '-L', str(b)).splitlines()[1:]]
    minos = re.findall(r'minos (\S+)', run('otool', '-l', str(b)))
    report[f'macos_{arch}'] = {'architectures': run('lipo', '-archs', str(b)).split(), 'minimum_macos': minos,
                               'exports': exported, 'linked_libraries': libs}
dll = (build / 'entropic-hdr-windows-x64' / 'entropic-hdr.dll').read_bytes()
report['windows_x64'] = {'import_libraries': pe_info.imports(dll), 'exports': pe_info.exports(dll)}
so = build / 'entropic-hdr-linux-x64' / 'entropic-hdr.so'
dynamic = run('objdump', '-T', str(so)).splitlines()
undefined = [l.split() for l in dynamic if '*UND*' in l]
provided = {l.split()[-1] for l in run('objdump', '-T', str(deps / 'linux' / 'libobs.so.30')).splitlines() if '*UND*' not in l and l[:1].isdigit()}
outside = sorted(f[-1] for f in undefined if not any(v.startswith(('GLIBC_', '(GLIBC_')) for v in f) and f[-1] not in provided)
headers = run('objdump', '-p', str(so))
report['linux_x64'] = {'needed': re.findall(r'NEEDED\s+(\S+)', headers), 'rpath': re.findall(r'R(?:UN)?PATH\s+(\S+)', headers),
                       'undefined_symbols': len(undefined), 'unresolved_outside_glibc_and_obs': outside,
                       'exports': sorted(l.split()[-1] for l in dynamic if '*UND*' not in l and ' g ' in l and 'DF .text' in l),
                       'max_glibc': max(re.findall(r'GLIBC_([0-9.]+)', run('objdump', '-T', str(so))), key=lambda v: tuple(map(int, v.split('.'))))}
print(json.dumps(report, indent=2))
