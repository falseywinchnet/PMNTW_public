#!/bin/zsh
# Runtime checks of a packaged Entropic HDR universal binary against the
# isolated official OBS 32.2.1 runtimes prepared by build-release.sh.
#
# usage: tools/run-macos-checks.sh DEPS_DIR ENTROPIC_HDR_BINARY RVFX_0.4.0_BINARY OUT_DIR
set -euo pipefail
ROOT=${0:A:h:h}
DEPS=${1:A}; MODULE=${2:A}; RVFX=${3:A}; OUT=$4
mkdir -p $OUT; OUT=${OUT:A}
OBS=$DEPS/obs-studio-32.2.1; SIMDE=$DEPS/simde-0.8.2
printf '#pragma once\n\n#define OBS_RELEASE_CANDIDATE 0\n#define OBS_BETA 0\n' > $OUT/obsconfig.h
inc=(-I$ROOT/include -I$OUT -I$OBS/libobs -I$OBS/libobs/util -I$SIMDE)
warn=(-Wall -Wextra -Wno-gnu-anonymous-struct -Wno-nested-anon-types)
for arch in arm64 x64; do
  a=$([[ $arch == arm64 ]] && echo arm64 || echo x86_64); fw=$DEPS/OBS-$arch.app/Contents/Frameworks
  clang++ -arch $a -std=c++17 -O2 $warn $inc $ROOT/tools/inspect-module.cpp $fw/libobs.framework/libobs \
    -Wl,-rpath,$fw -o $OUT/inspect-module-$arch
done
fw=$DEPS/OBS-arm64.app/Contents/Frameworks
clang++ -std=c++17 -O3 -DNDEBUG -I$ROOT/include -c $ROOT/src/entropy_stretch.cpp -o $OUT/entropy-core.o
clang++ -x objective-c++ -std=c++17 -O2 $warn $inc -c $ROOT/tools/entropy_obs_smoke.mm -o $OUT/entropy-smoke.o
clang++ $OUT/entropy-smoke.o $OUT/entropy-core.o $fw/libobs.framework/libobs -framework AppKit -Wl,-rpath,$fw -o $OUT/entropy-smoke
clang++ -x objective-c++ -std=c++17 -O2 $warn $inc -c $ROOT/tools/dual_module_smoke.mm -o $OUT/dual-module-smoke.o
clang++ $OUT/dual-module-smoke.o $fw/libobs.framework/libobs -framework AppKit -Wl,-rpath,$fw -o $OUT/dual-module-smoke

metal=$fw/libobs-metal.dylib
$OUT/inspect-module-arm64 $MODULE entropy_decorrelation_stretch > $OUT/properties-arm64.log 2>&1
arch -x86_64 $OUT/inspect-module-x64 $MODULE entropy_decorrelation_stretch > $OUT/properties-x86_64-rosetta.log 2>&1
$OUT/entropy-smoke $MODULE $metal $OUT/entropy-shipped.ppm > $OUT/entropy-shipped-look.log 2>&1
$OUT/entropy-smoke $MODULE $metal $OUT/entropy-legacy.ppm --legacy-look > $OUT/entropy-legacy-look.log 2>&1
$OUT/dual-module-smoke $metal $RVFX $MODULE > $OUT/dual-rvfx-first.log 2>&1
$OUT/dual-module-smoke $metal $MODULE $RVFX > $OUT/dual-entropic-hdr-first.log 2>&1
grep -h -E '^(DEFAULTS|PROPERTY es_(decorrelation|allocation|chains))|look:|byte error|passed|registrations|already|Entropic HDR\]' $OUT/*.log
