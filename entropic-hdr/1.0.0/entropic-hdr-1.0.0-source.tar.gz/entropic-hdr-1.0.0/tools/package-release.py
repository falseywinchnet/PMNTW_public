#!/usr/bin/env python3
"""Package already built, checked Entropic HDR modules; never substitutes source for binaries."""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, pathlib, plistlib, subprocess, tarfile, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
MODULE = 'entropic-hdr'
VERSION = '1.0.0'
RELEASE = '2026.10.16'
DATE = (2026, 10, 16, 0, 0, 0)
EPOCH = 1792108800
REGISTRATIONS = ['entropy_decorrelation_stretch']
BASELINE = {'release': '2026.09.10', 'module': 'realtime-vector-fx 0.4.0',
            'source_archive': 'obs-plugins-2026.09.10-source.tar.gz',
            'source_archive_sha256': 'b6291ee4700b10e5d32d990981259bf9a9470dd39659388ea06ea7698f1f0f49'}
# Release source path in this tree -> path in the 2026.09.10 source archive.
ORIGINS = {
    'include/rvfx/entropy_stretch.hpp': 'source/realtime_vector_fx/include/rvfx/entropy_stretch.hpp',
    'src/entropy_stretch.cpp': 'source/realtime_vector_fx/src/entropy_stretch.cpp',
    'obs/entropic-hdr-filter.cpp': 'source/realtime_vector_fx/obs/entropy-filter.cpp',
    'obs/Info.plist.in': 'source/realtime_vector_fx/obs/Info.plist.in',
    'tests/test_entropy_stretch.cpp': 'source/realtime_vector_fx/tests/test_entropy_stretch.cpp',
    'tests/test_entropy_chains.cpp': 'source/realtime_vector_fx/tests/test_entropy_chains.cpp',
    'tests/reference/entropy_filter_v1.cpp': 'source/realtime_vector_fx/tests/reference/entropy_filter_v1.cpp',
    'tests/reference/entropy_stretch_v1.cpp': 'source/realtime_vector_fx/tests/reference/entropy_stretch_v1.cpp',
    'tests/reference/entropy_stretch_v1.hpp': 'source/realtime_vector_fx/tests/reference/entropy_stretch_v1.hpp',
    'tools/entropy_benchmark.cpp': 'source/realtime_vector_fx/tools/entropy_benchmark.cpp',
    'tools/entropy_demo.cpp': 'source/realtime_vector_fx/tools/entropy_demo.cpp',
    'tools/entropy_obs_smoke.mm': 'source/realtime_vector_fx/tools/entropy_obs_smoke.mm',
    'tools/inspect-module.cpp': 'tools/inspect-module.cpp',
    'tools/prepare-zig-wrappers.py': 'tools/prepare-zig-wrappers.py',
    'tools/package-release.py': 'tools/package-release.py',
    'toolchains/linux-x64.cmake': 'toolchains/linux-x64.cmake',
    'toolchains/windows-x64.cmake': 'toolchains/windows-x64.cmake',
    **{f'docs/{n}': f'source/realtime_vector_fx/{n}' for n in
       ['ENTROPY_STRETCH.md', 'ENTROPY_CHAINS.md', 'ENTROPY_OPTIMIZATION.md', 'ENTROPY_VERIFICATION.md']},
}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def source_files():
    # Evidence and packages are produced from this source, so neither is part of it.
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).parts[0] not in ('evidence', 'dist')
                  and '__pycache__' not in p.parts and p.suffix != '.pyc' and p.name != '.DS_Store')

def baseline_identity(source_hashes, archive):
    if archive is None:
        return {}
    with tarfile.open(archive) as tar:
        names = {m.name.split('/', 1)[1]: m for m in tar.getmembers() if m.isfile()}
        old = {path: sha(tar.extractfile(names[origin]).read()) for path, origin in ORIGINS.items()}
    return {'unchanged': sorted(p for p in ORIGINS if source_hashes.get(p) == old[p]),
            'modified': sorted(p for p in ORIGINS if p in source_hashes and source_hashes[p] != old[p]),
            'new': sorted(p for p in source_hashes if p not in ORIGINS and not p.startswith('licenses/'))}

# Split literals, so this script can ship in the source archive it checks.
FORBIDDEN = (b'/' b'users/', b'/' b'home/')

def write_archive(path, members):
    """members: relative name -> (bytes, Unix mode), deterministic envelopes."""
    # No build-host or personal paths may ship, in binaries or text.
    leaks = sorted(name for name, (data, _) in members.items() if any(f in data.lower() for f in FORBIDDEN))
    if leaks:
        raise SystemExit(f'{path.name}: home-folder path found in {", ".join(leaks)}')
    if path.suffix == '.zip':
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, (data, mode) in sorted(members.items()):
                info=zipfile.ZipInfo(name, DATE);info.create_system=3;info.external_attr=(0o100000|mode)<<16;info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,data)
    else:
        with path.open('wb') as raw, gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz, tarfile.open(fileobj=gz,mode='w') as tar:
            for name,(data,mode) in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mtime=EPOCH;info.mode=mode;info.uid=info.gid=0;info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(data))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-root',type=pathlib.Path,required=True,help='holds entropic-hdr-{macos-arm64,macos-x64,windows-x64,linux-x64}/')
    p.add_argument('--output',type=pathlib.Path,required=True)
    p.add_argument('--staging',type=pathlib.Path,required=True)
    p.add_argument('--baseline-source',type=pathlib.Path,help=BASELINE['source_archive'])
    p.add_argument('--revision',help='release source commit, when packaging outside the Git checkout')
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    files=source_files();source_hashes={str(f.relative_to(ROOT)):sha(f.read_bytes()) for f in files}
    fingerprint=sha(json.dumps(source_hashes,sort_keys=True,separators=(',',':')).encode())
    revision=args.revision or subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
    if not args.revision and subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain','--','.',':!evidence',':!dist'],text=True).strip():
        raise SystemExit('Release source has uncommitted changes; commit before packaging.')
    provenance={'release':RELEASE,'release_source_commit':revision,'source_tree_sha256':fingerprint,'source_files':source_hashes,
        'derived_from':{**BASELINE,**baseline_identity(source_hashes,args.baseline_source)},
        'obs_headers':'32.2.1','simde':'0.8.2',
        'macos_toolchain':'Apple Clang 21.0.0.21000101, SDK 26.5, deployment target 13.0',
        'windows_toolchain':'GCC 16.1.0 / MinGW-w64 14.0.0, x86_64 baseline, static runtime',
        'linux_toolchain':'Zig 0.14.1 / Clang 19.1.7, x86_64-linux-gnu.2.35, static libc++',
        'runtime_verification':{'macos_arm64':'Native OBS 32.2.1 libobs/Metal rendering: shipped and 0.4.0 looks, Chains, CPU/GPU agreement, freeze, zero-strength exact bypass, HDR passthrough; single registration with Realtime Vector FX 0.4.0 loaded in either order',
            'macos_x86_64':'Module load, registration, defaults and properties under Rosetta on Apple Silicon; not native Intel hardware testing',
            'windows_x64':'Cross-built; imports/exports inspected; not native runtime tested',
            'linux_x64':'Cross-built; ELF dependencies/exports inspected; not native runtime tested'},
        'licenses':'Project source MIT; OBS-linked binaries GPL-2.0-or-later; bundled dependency/runtime notices.'}
    notices={f'licenses/{f.name}':(f.read_bytes(),0o644) for f in sorted((ROOT/'licenses').iterdir()) if f.is_file()}
    artifacts=[]
    for target in ['windows-x64','macos-universal','linux-x64']:
        meta={**provenance,'module':MODULE,'version':VERSION,'target':target,'registrations':REGISTRATIONS}
        members=dict(notices)
        if target=='macos-universal':
            bundle=args.staging/f'{MODULE}.plugin';(bundle/'Contents/MacOS').mkdir(parents=True,exist_ok=True);(bundle/'Contents/Resources').mkdir(exist_ok=True)
            binary=bundle/'Contents/MacOS'/MODULE
            subprocess.run(['lipo','-create',str(args.build_root/'entropic-hdr-macos-arm64'/MODULE),str(args.build_root/'entropic-hdr-macos-x64'/MODULE),'-output',str(binary)],check=True)
            plist=plistlib.loads((ROOT/'obs/Info.plist.in').read_text().replace('@PROJECT_VERSION@',VERSION).encode());plist['LSMinimumSystemVersion']='13.0'
            (bundle/'Contents/Info.plist').write_bytes(plistlib.dumps(plist))
            subprocess.run(['codesign','--force','--sign','-',str(bundle)],check=True)
            subprocess.run(['codesign','--verify','--strict',str(bundle)],check=True)
            for f in sorted(bundle.rglob('*')):
                if f.is_file():members[str(f.relative_to(bundle.parent))]=(f.read_bytes(),0o755 if f==binary else 0o644)
            arches=['arm64','x86_64'];extension='zip';location=f'~/Library/Application Support/obs-studio/plugins/{MODULE}.plugin'
            install=f'Copy {MODULE}.plugin into ~/Library/Application Support/obs-studio/plugins/.\nThe universal bundle includes arm64 and x86_64 and targets macOS 13+.\nIt is ad hoc signed, not Developer ID signed or notarized. If macOS blocks it,\nverify the download checksum and use the local security approval provided by\nmacOS. If a downloaded bundle retains quarantine, the following targets only\nthis verified plugin after copying:\n\nxattr -dr com.apple.quarantine "$HOME/Library/Application Support/obs-studio/plugins/{MODULE}.plugin"\n'
        else:
            suffix='.dll' if target=='windows-x64' else '.so';binary=args.build_root/f'entropic-hdr-{target}'/(MODULE+suffix)
            if not binary.is_file():raise SystemExit(f'Missing genuine binary: {binary}')
            members[f'{MODULE}/bin/64bit/{MODULE}{suffix}']=(binary.read_bytes(),0o755)
            members[f'{MODULE}/data/locale/en-US.ini']=(b'# Filter labels are embedded in this release.\n',0o644)
            arches=['x86_64'];extension='zip' if target=='windows-x64' else 'tar.gz'
            location=f'C:\\ProgramData\\obs-studio\\plugins\\{MODULE}' if target=='windows-x64' else f'~/.config/obs-studio/plugins/{MODULE}'
            install=f'Copy the {MODULE} folder into '+('C:\\ProgramData\\obs-studio\\plugins\\.\nKeep its bin/64bit and data/locale folders together. This is a Windows 10/11\nx64 package; it is not a Windows ARM64 build.\n' if target=='windows-x64' else '~/.config/obs-studio/plugins/.\nKeep its bin/64bit and data/locale folders together. This x86_64 package needs\nglibc 2.35+ and standard native OBS with libobs.so.30. OBS distribution\ndependencies also apply. It is not an OBS Flatpak package.\n')
        meta['architectures']=arches;meta['binary_sha256']=sha(binary.read_bytes());meta['install_location']=location
        members['build-provenance.json']=(json.dumps(meta,indent=2,sort_keys=True).encode()+b'\n',0o644)
        readme=f'''Entropic HDR {VERSION} — release {RELEASE}

Entropic HDR measures local color entropy in the live picture and uses it to
decide where to stretch brightness and color contrast. Add it to a video
source from the source's Filters list, where it appears as "Entropic HDR".
Defaults: decorrelation 0.09, allocation 0.11, Chains off.

Requires OBS Studio 32.2.1. Close OBS before copying files, then reopen OBS.

{install}
This package registers: {', '.join(REGISTRATIONS)}.

Scenes saved with the Entropy-Guided Decorrelation Stretch from Realtime
Vector FX 0.4.0 load with Entropic HDR, because the filter id is unchanged.
Values a scene saved explicitly are kept; values left at the old defaults
(decorrelation 0.65, allocation 0.80) now take the new defaults.

If Realtime Vector FX 0.4.0 is also installed, OBS registers the filter only
once. Whichever module OBS loads first provides it, and the other declines
with a log message. Modules in the same plugin folder normally load in
alphabetical order, which puts Entropic HDR first.

Native rendering was verified on macOS Apple Silicon with OBS 32.2.1 Metal.
Intel loading/registration was checked under Rosetta, not Intel hardware.
Windows/Linux are cross-built and ABI-inspected, not native runtime tested.
The filter is an SDR display-color transform; HDR and floating-point SDR
sources pass through unchanged. Inspect build-provenance.json for exact
target and source fingerprints.

Source archive: entropic-hdr-{VERSION}-source.tar.gz, published with this package.
Installation reference: https://obsproject.com/kb/plugins-guide

Project source is MIT; OBS-linked plugin binaries are GPL version 2 or later.
All included third-party license notices are in licenses/. OBS is not bundled.
'''
        members['README.txt']=(readme.encode(),0o644)
        name=f'{MODULE}-{VERSION}-{target}.{extension}';out=args.output/name;write_archive(out,members)
        artifacts.append({'filename':name,'kind':'binary','module':MODULE,'version':VERSION,'platform':target,'architectures':arches,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'binary_sha256':meta['binary_sha256'],'install_location':location})
    prefix=f'{MODULE}-{VERSION}'
    source_members={f'{prefix}/'+name:(f.read_bytes(),0o755 if f.suffix in ('.py','.sh') else 0o644) for f in files for name in [str(f.relative_to(ROOT))]}
    source_members[f'{prefix}/source-hashes.json']=(json.dumps(source_hashes,indent=2,sort_keys=True).encode()+b'\n',0o644)
    source_name=f'{prefix}-source.tar.gz';out=args.output/source_name;write_archive(out,source_members)
    artifacts.append({'filename':source_name,'kind':'source','bytes':out.stat().st_size,'sha256':sha(out.read_bytes())})
    manifest={'schema':'pmnw.obs-release-v1',**provenance,'artifacts':artifacts}
    (args.output/'release-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    (args.output/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {a['filename']}\n" for a in artifacts))
    print(json.dumps({'output':str(args.output),'binary_archives':3,'source_archives':1,'source_tree_sha256':fingerprint},indent=2))

if __name__=='__main__':main()
