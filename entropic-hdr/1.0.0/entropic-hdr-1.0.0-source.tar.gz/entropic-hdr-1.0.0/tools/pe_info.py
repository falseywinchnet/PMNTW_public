#!/usr/bin/env python3
"""Minimal PE32+ reader: exported names and imported DLLs. Usage: pe_info.py def|imports|exports FILE"""
import struct, sys

def _sections(data):
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    assert data[pe:pe+4] == b'PE\0\0', 'not a PE file'
    count, opt_size = struct.unpack_from('<H', data, pe+6)[0], struct.unpack_from('<H', data, pe+20)[0]
    opt = pe + 24
    assert struct.unpack_from('<H', data, opt)[0] == 0x20b, 'not PE32+'
    dirs = [struct.unpack_from('<II', data, opt+112+8*i) for i in range(16)]
    table = opt + opt_size
    secs = [struct.unpack_from('<IIII', data, table+40*i+8) for i in range(count)]  # vsize, va, rawsize, rawptr
    def offset(rva):
        for vsize, va, rawsize, rawptr in secs:
            if va <= rva < va + max(vsize, rawsize):
                return rawptr + rva - va
        raise ValueError(hex(rva))
    return dirs, offset

def _cstr(data, at):
    return data[at:data.index(b'\0', at)].decode()

def exports(data):
    dirs, offset = _sections(data)
    rva, size = dirs[0]
    if not rva:
        return []
    d = offset(rva)
    names, table = struct.unpack_from('<I', data, d+24)[0], offset(struct.unpack_from('<I', data, d+32)[0])
    return sorted(_cstr(data, offset(struct.unpack_from('<I', data, table+4*i)[0])) for i in range(names))

def imports(data):
    dirs, offset = _sections(data)
    rva, _ = dirs[1]
    found, d = [], offset(rva)
    while True:
        name = struct.unpack_from('<I', data, d+12)[0]
        if not name:
            return sorted(found)
        found.append(_cstr(data, offset(name)))
        d += 20

if __name__ == '__main__':
    mode, path = sys.argv[1], sys.argv[2]
    data = open(path, 'rb').read()
    if mode == 'def':
        print('LIBRARY obs.dll\nEXPORTS'); print('\n'.join(f'  {n}' for n in exports(data)))
    else:
        print('\n'.join(exports(data) if mode == 'exports' else imports(data)))
