// Loads two modules that both provide entropy_decorrelation_stretch into one
// libobs process, in the given order, and checks that the id is registered once.
// usage: dual-module-smoke libobs-metal.dylib first-module second-module
#include <obs.h>
#include <util/base.h>
#import <AppKit/AppKit.h>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
namespace {
constexpr const char* source_id="entropy_decorrelation_stretch";
int errors=0,duplicates=0,skips=0;log_handler_t logger=nullptr;void* logger_arg=nullptr;
void log(int level,const char* format,va_list args,void*){
    va_list copy;va_copy(copy,args);char line[2048];std::vsnprintf(line,sizeof line,format,copy);va_end(copy);
    if(level==LOG_ERROR)++errors;
    if(std::strstr(line,source_id)&&std::strstr(line,"already exists"))++duplicates;
    if(std::strstr(line,"[Entropic HDR]")&&std::strstr(line,"already registered"))++skips;
    if(logger)logger(level,format,args,logger_arg);
}
void check(bool value,const char* why){if(!value){std::fprintf(stderr,"FAIL: %s\n",why);std::exit(10);}}
bool load(const char* path){obs_module_t* module=nullptr;
    return obs_open_module(&module,path,"/tmp")==MODULE_SUCCESS&&obs_init_module(module);}
}
int main(int argc,char** argv){@autoreleasepool {
    if(argc<4)return 2;[NSApplication sharedApplication];base_get_log_handler(&logger,&logger_arg);base_set_log_handler(log,nullptr);
    check(obs_startup("en-US",nullptr,nullptr),"OBS startup");obs_video_info v{};v.graphics_module=argv[1];v.fps_num=60;v.fps_den=1;
    v.base_width=v.output_width=320;v.base_height=v.output_height=180;v.output_format=VIDEO_FORMAT_RGBA;v.gpu_conversion=true;
    v.colorspace=VIDEO_CS_709;v.range=VIDEO_RANGE_FULL;check(obs_reset_video(&v)==OBS_VIDEO_SUCCESS,"Metal startup");
    check(load(argv[2]),"first module load");check(load(argv[3]),"second module load");
    int registered=0;const char* type=nullptr;
    for(size_t i=0;obs_enum_filter_types(i,&type);++i)if(std::strcmp(type,source_id)==0)++registered;
    const char* name=obs_source_get_display_name(source_id);
    auto* filter=obs_source_create_private(source_id,"entropy-filter",nullptr);check(filter!=nullptr,"filter create");
    auto* defaults=obs_get_source_defaults(source_id);
    std::printf("registrations %d; display name \"%s\"; default decorrelation %.2f allocation %.2f; "
                "libobs duplicate rejections %d; Entropic HDR skips %d; libobs errors %d\n",
        registered,name?name:"(none)",obs_data_get_double(defaults,"es_decorrelation"),
        obs_data_get_double(defaults,"es_allocation"),duplicates,skips,errors);
    obs_data_release(defaults);obs_source_release(filter);
    check(registered==1,"id registered exactly once");check(duplicates+skips==1,"second provider declined exactly once");
    check(errors==0,"no libobs errors");obs_shutdown();
    std::puts("single registration with both modules loaded passed");return 0;
}}
