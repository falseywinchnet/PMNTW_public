#!/usr/bin/env python3
"""Verify pinned dependency downloads against recorded SHA-256 digests."""
import hashlib, json, pathlib, sys
expected = json.loads(pathlib.Path(sys.argv[1]).read_text())
folder = pathlib.Path(sys.argv[2])
bad = []
for name, digest in sorted(expected.items()):
    h = hashlib.sha256()
    with (folder / name).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    print(('ok   ' if h.hexdigest() == digest else 'FAIL ') + name)
    if h.hexdigest() != digest:
        bad.append(name)
sys.exit(1 if bad else 0)
