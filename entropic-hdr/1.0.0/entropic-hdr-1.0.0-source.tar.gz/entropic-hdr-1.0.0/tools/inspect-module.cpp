#include <obs-module.h>
#include <cstdio>
#include <cstring>
int main(int argc,char **argv) {
 if(argc<3 || !obs_startup("en-US",nullptr,nullptr)) return 2;
 obs_module_t *module=nullptr;
 if(obs_open_module(&module,argv[1],"/tmp")!=MODULE_SUCCESS || !obs_init_module(module)) return 3;
 obs_data_t *d=obs_get_source_defaults(argv[2]);
 if(!d)return 4;
 std::printf("DEFAULTS %s\n",obs_data_get_json_with_defaults(d));
 obs_data_release(d);
 obs_properties_t *p=obs_get_source_properties(argv[2]);
 for(obs_property_t *v=obs_properties_first(p);v;obs_property_next(&v)){
  auto type=obs_property_get_type(v);
  std::printf("PROPERTY %s | %s | %d",obs_property_name(v),obs_property_description(v),(int)type);
  if(type==OBS_PROPERTY_FLOAT)std::printf(" | %.17g %.17g %.17g",obs_property_float_min(v),obs_property_float_max(v),obs_property_float_step(v));
  if(type==OBS_PROPERTY_INT)std::printf(" | %d %d %d",obs_property_int_min(v),obs_property_int_max(v),obs_property_int_step(v));
  std::puts("");
  if(type==OBS_PROPERTY_LIST)for(size_t i=0;i<obs_property_list_item_count(v);++i)std::printf("ITEM %s | %lld\n",obs_property_list_item_name(v,i),(long long)obs_property_list_item_int(v,i));
 }
 obs_properties_destroy(p);obs_shutdown();return 0;
}
