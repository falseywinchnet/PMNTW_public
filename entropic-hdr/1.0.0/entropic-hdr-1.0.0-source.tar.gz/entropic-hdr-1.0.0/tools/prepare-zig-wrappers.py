#!/usr/bin/env python3
"""Create build-local archive wrappers for CMake's single-path AR/RANLIB fields."""
import argparse
import pathlib
import shlex
p = argparse.ArgumentParser()
p.add_argument('dependency_directory', type=pathlib.Path)
a = p.parse_args()
zig = a.dependency_directory.resolve() / 'zig-aarch64-macos-0.14.1' / 'zig'
if not zig.is_file():
    raise SystemExit(f'Missing pinned Zig compiler: {zig}')
for action in ('ar', 'ranlib'):
    wrapper = a.dependency_directory / f'zig-{action}'
    wrapper.write_text(f'#!/bin/sh\nexec {shlex.quote(str(zig))} {action} "$@"\n')
    wrapper.chmod(0o755)
