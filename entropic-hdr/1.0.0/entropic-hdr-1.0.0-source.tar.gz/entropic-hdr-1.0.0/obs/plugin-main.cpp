#include <obs-module.h>

OBS_DECLARE_MODULE()

bool entropic_hdr_register_filter();

MODULE_EXPORT const char* obs_module_name(void) { return "Entropic HDR"; }

MODULE_EXPORT const char* obs_module_description(void) {
    return "Entropic HDR: entropy-guided decorrelation and contrast allocation for live SDR video";
}

bool obs_module_load(void) {
    // A skipped duplicate is not a load failure; OBS keeps the other copy's filter.
    if (entropic_hdr_register_filter())
        blog(LOG_INFO, "[Entropic HDR] filter registered");
    return true;
}
