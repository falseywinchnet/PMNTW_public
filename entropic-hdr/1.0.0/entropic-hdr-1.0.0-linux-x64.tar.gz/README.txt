Entropic HDR 1.0.0 — release 2026.10.16

Entropic HDR measures local color entropy in the live picture and uses it to
decide where to stretch brightness and color contrast. Add it to a video
source from the source's Filters list, where it appears as "Entropic HDR".
Defaults: decorrelation 0.09, allocation 0.11, Chains off.

Requires OBS Studio 32.2.1. Close OBS before copying files, then reopen OBS.

Copy the entropic-hdr folder into ~/.config/obs-studio/plugins/.
Keep its bin/64bit and data/locale folders together. This x86_64 package needs
glibc 2.35+ and standard native OBS with libobs.so.30. OBS distribution
dependencies also apply. It is not an OBS Flatpak package.

This package registers: entropy_decorrelation_stretch.

Scenes saved with the Entropy-Guided Decorrelation Stretch from Realtime
Vector FX 0.4.0 load with Entropic HDR, because the filter id is unchanged.
Values a scene saved explicitly are kept; values left at the old defaults
(decorrelation 0.65, allocation 0.80) now take the new defaults.

If Realtime Vector FX 0.4.0 is also installed, OBS registers the filter only
once. Whichever module OBS loads first provides it, and the other declines
with a log message. Modules in the same plugin folder normally load in
alphabetical order, which puts Entropic HDR first.

Native rendering was verified on macOS Apple Silicon with OBS 32.2.1 Metal.
Intel loading/registration was checked under Rosetta, not Intel hardware.
Windows/Linux are cross-built and ABI-inspected, not native runtime tested.
The filter is an SDR display-color transform; HDR and floating-point SDR
sources pass through unchanged. Inspect build-provenance.json for exact
target and source fingerprints.

Source archive: entropic-hdr-1.0.0-source.tar.gz, published with this package.
Installation reference: https://obsproject.com/kb/plugins-guide

Project source is MIT; OBS-linked plugin binaries are GPL version 2 or later.
All included third-party license notices are in licenses/. OBS is not bundled.
